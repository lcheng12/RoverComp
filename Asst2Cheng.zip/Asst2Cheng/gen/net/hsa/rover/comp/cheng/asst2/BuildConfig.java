/** Automatically generated file. DO NOT MODIFY */
package net.hsa.rover.comp.cheng.asst2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}