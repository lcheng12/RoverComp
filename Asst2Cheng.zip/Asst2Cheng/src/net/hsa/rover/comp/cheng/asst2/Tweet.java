package net.hsa.rover.comp.cheng.asst2;

public class Tweet {

	private String text;
	
	//	private String assignment;
	
	public Tweet(String text) {
		this.text = text;
		//		this.assignment = assignment;
	}

	public String getText() {
		return text;
	}

}
