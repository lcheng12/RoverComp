package net.hsa.rover.comp.cheng.asst2;

public class AssignmentAdapter {

}
